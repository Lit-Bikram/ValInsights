"use client";

import { useEffect, useRef } from "react";
import { usePathname } from "next/navigation";

type PageRevealProps = {
  children: React.ReactNode;
};

export default function PageReveal({ children }: PageRevealProps) {
  const rootRef = useRef<HTMLDivElement>(null);
  const pathname = usePathname();

  useEffect(() => {
    const root = rootRef.current;

    if (!root) {
      return;
    }

    const mainElements = root.querySelectorAll<HTMLElement>("main");
    const observers: IntersectionObserver[] = [];

    mainElements.forEach((main) => {
      /*
       * Home and Solutions already use their own
       * ScrollReveal animations.
       */
      if (
        main.classList.contains("home-page") ||
        main.classList.contains("solutions-page")
      ) {
        return;
      }

      /*
       * Only reveal the main page sections.
       */
      const sections = Array.from(
        main.querySelectorAll<HTMLElement>("section")
      );

      sections.forEach((section, index) => {
        /*
         * Hero sections should appear immediately.
         */
        const isHero =
          index === 0 ||
          section.classList.contains("about-hero") ||
          section.classList.contains("sectors-hero") ||
          section.classList.contains("sector-hero") ||
          section.classList.contains("service-hero") ||
          section.classList.contains("insights-hero") ||
          section.classList.contains("contact-hero");

        if (isHero) {
          section.classList.remove(
            "page-section-reveal",
            "page-section-visible"
          );

          section.style.removeProperty("--page-reveal-delay");

          return;
        }

        /*
         * Prepare section for reveal.
         */
        section.classList.remove("page-section-visible");
        section.classList.add("page-section-reveal");

        section.style.setProperty(
          "--page-reveal-delay",
          `${Math.min(index * 70, 210)}ms`
        );
      });

      const revealSections = main.querySelectorAll<HTMLElement>(
        ".page-section-reveal"
      );

      if (!revealSections.length) {
        return;
      }

      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (!entry.isIntersecting) {
              return;
            }

            entry.target.classList.add("page-section-visible");

            observer.unobserve(entry.target);
          });
        },
        {
          threshold: 0.08,
          rootMargin: "0px 0px -50px 0px",
        }
      );

      revealSections.forEach((section) => {
        observer.observe(section);
      });

      observers.push(observer);
    });

    return () => {
      observers.forEach((observer) => {
        observer.disconnect();
      });
    };
  }, [pathname]);

  return <div ref={rootRef}>{children}</div>;
}